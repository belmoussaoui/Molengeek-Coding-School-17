# 1 Créer un nouveau projet
# 2 En faire un projet git
# 3 Faire une sauvegarde avec un fichier index.html du nom de "mon premier commit"
# 4 Faire une sauvegarde avec un fichier index.html et style.css du nom "second commit"
# 5 Faire une derniere sauvegarde  avec juste le fichier index.html et contact.html(attention de pas supprimer le fichier css)