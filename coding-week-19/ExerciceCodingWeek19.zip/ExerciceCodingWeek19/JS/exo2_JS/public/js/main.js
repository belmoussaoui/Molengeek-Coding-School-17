let prenom = 'Saîd';
let age = 13;

alert(age);
alert(prenom);

alert("Je m'appelle " + prenom);
alert("J'ai " + age + ' ans');