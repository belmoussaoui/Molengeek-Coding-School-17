let a = 5;
let b = 8;
let c = 10;

let temp = a;
a = b;
b = c;
c = temp;

console.log(`a = ${a}`);
console.log(`b = ${b}`);
console.log(`c = ${c}`);

// La variable "a" doit valoir la valeur de "b", la variable "b" doit valoir la valeur de "c" et la variable "c" doit valoir la valeur de "a".

// On ne peut réassigner la valeur des variable que via les autres variables.