console.log('Hello World !');
alert('Hello World !');

console.log(`Je m'appelle Said`);
alert(`Je m'appelle Bilal`);